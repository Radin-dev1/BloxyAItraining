SuperbulletAI 0.4.3 — bundled Roblox examples and reference assets
==================================================================

Source: SuperbulletAI 0.4.3 Windows executable supplied by the user.
The executable contains a Squirrel/NuGet package. This archive collects the Roblox plugin builds, project templates, and Luau type reference found in that package.

These are app-bundled example/reference assets. Inspection did not find a standalone model-training corpus or model weights, so this archive should not be described as verified AI training data. It can serve as a small Roblox code/project example set for exploration or dataset preparation.

Contents are preserved in their original formats. `MANIFEST.json` gives each included file’s size and SHA-256.
