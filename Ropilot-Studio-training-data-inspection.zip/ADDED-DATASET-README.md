# Added documentation dataset

This directory adds descriptive metadata to the existing ZIP. It does not claim that the installer contains training examples.

## Files

- `package-facts.json`: machine-readable summary of the installer format, package counts, and data inspection result.
- `file-categories.csv`: categorized examples of payload files and whether they are training data.
- `training-example.jsonl`: one explicitly synthetic educational example showing how the metadata could be represented as an instruction/response record. It is not extracted from Ropilot and is not a genuine training sample.

## Categories observed

- Application code: JavaScript and HTML files in the app bundle.
- Runtime: Electron/Chromium DLLs, ICU data, resource packs, and V8 snapshots.
- Dependencies: bundled Node modules.
- Interface media: images, fonts, and a video asset.
- Helpers: Ropilot helper executables.
- Training data: none found in the installer.
