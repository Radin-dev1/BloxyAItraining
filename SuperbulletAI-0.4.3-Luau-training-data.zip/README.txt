SuperbulletAI 0.4.3 — Luau code corpus
======================================

`train.jsonl` contains Luau source records extracted from Roblox plugin model assets bundled in the user-provided SuperbulletAI 0.4.3 executable. It contains code only: no application binaries, UI assets, or runtime dependencies.

The package metadata identifies SuperbulletAI as proprietary and no redistribution license was found. This archive is prepared locally for review/use. Do not publish or redistribute the extracted source unless you have authorization from the rights holder.

`MANIFEST.json` records the source executable hash and each extracted script’s origin and size.
